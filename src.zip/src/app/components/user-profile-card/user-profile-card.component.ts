import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { EMPTY, Observable, map } from 'rxjs';
import { AppState, selectUser } from 'src/app/store/selectors/auth.selectors';
import { User } from './user.model'; // Adjust the import path as needed

@Component({
  selector: 'app-user-profile-card',
  templateUrl: './user-profile-card.component.html',
  styleUrls: ['./user-profile-card.component.css']
})
export class UserProfileCardComponent implements OnInit {
  // user$: Observable<User> = EMPTY;
  user: User = new User();

  constructor(private store: Store<AppState>) { }

  ngOnInit(): void {
    this.store.select(selectUser).subscribe(userData => {
      this.user = new User(userData); // Update user with data from Redux
      console.log(userData)
    });
  }
}
