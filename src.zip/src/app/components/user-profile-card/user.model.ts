export class User {
    name: string;
    email: string;
    mobile: string;
    gender: string;
    imageUrl: string;
    location: string;

    constructor(user: any = {}) {
        this.name = user.name || 'Default Name';
        this.email = user.email || 'default@example.com';
        this.mobile = user.mobile || '000-000-0000';
        this.gender = user.gender || 'Not Specified';
        this.imageUrl = user.imageUrl || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80';
        this.location = user.location || "Banglore"
    }
}
